import json
import numpy as np
import yfinance as yf
import pandas as pd

def lambda_handler(event, context):
    # Decode the JSON POST data
    post_data = json.loads(event['body'])
    
    # Extract parameters from the POST data
    days = int(post_data.get('d', 365))
    ticker = post_data.get('h', 'AMZN')
    signal_type = post_data.get('t', 'buy')
    body_multiplier = float(post_data.get('p', 0.75))

    # Download stock data
    data = fetch_data(ticker, days)

    # Calculate buy/sell signals based on the provided type
    if signal_type == 'sell':
        calculate_sell_signals(data, body_multiplier)
    else:
        calculate_buy_signals(data, body_multiplier)

    # Perform Monte Carlo simulation
    results = monte_carlo_simulation(data, days, shots=100)

    # Prepare and return the response
    response = {'result': 'ok'}
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps(response)
    }

def fetch_data(ticker, period):
    """Fetches historical stock data from Yahoo Finance for the specified period."""
    return yf.download(ticker, period=f"{period}d")

def calculate_buy_signals(data, body_multiplier):
    data['Buy'] = 0
    body = (data['Close'] - data['Open']).abs().mean() * body_multiplier

    for i in range(2, len(data)):
        if is_three_soldiers(data, i, body):
            data.at[data.index[i], 'Buy'] = 1

def calculate_sell_signals(data, body_multiplier):
    data['Sell'] = 0
    body = (data['Close'] - data['Open']).abs().mean() * body_multiplier

    for i in range(2, len(data)):
        if is_three_crows(data, i, body):
            data.at[data.index[i], 'Sell'] = 1

def is_three_soldiers(data, i, body):
    return (data['Close'][i] - data['Open'][i]) >= body and \
           data['Close'][i] > data['Close'][i-1] > data['Close'][i-2] and \
           (data['Close'][i-1] - data['Open'][i-1]) >= body and \
           (data['Close'][i-2] - data['Open'][i-2]) >= body

def is_three_crows(data, i, body):
    return (data['Open'][i] - data['Close'][i]) >= body and \
           data['Close'][i] < data['Close'][i-1] < data['Close'][i-2] and \
           (data['Open'][i-1] - data['Close'][i-1]) >= body and \
           (data['Open'][i-2] - data['Close'][i-2]) >= body

def monte_carlo_simulation(data, days, shots):
    results = {"VaR 95": [], "VaR 99": [], "Profit/Loss": [], "Buys": data['Buy'].sum(), "Sells": data['Sell'].sum()}
    for _ in range(shots):
        simulated = np.random.normal(loc=0.05, scale=0.1, size=days)
        sorted_simulations = np.sort(simulated)
        results["VaR 95"].append(np.percentile(sorted_simulations, 5))
        results["VaR 99"].append(np.percentile(sorted_simulations, 1))
        results["Profit/Loss"].append(np.random.uniform(-100, 100))
    return results
